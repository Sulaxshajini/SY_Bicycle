﻿namespace BicycleManagementSystem
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.customerButton2 = new BicycleManagementSystem.CustomerButton();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.customerButton6 = new BicycleManagementSystem.CustomerButton();
            this.customerButton5 = new BicycleManagementSystem.CustomerButton();
            this.customerButton4 = new BicycleManagementSystem.CustomerButton();
            this.customerButton3 = new BicycleManagementSystem.CustomerButton();
            this.label1 = new System.Windows.Forms.Label();
            this.customerButton1 = new BicycleManagementSystem.CustomerButton();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panelMain = new System.Windows.Forms.Panel();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customerButton2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerButton6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerButton5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerButton4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerButton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerButton1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.customerButton2);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.customerButton6);
            this.panel1.Controls.Add(this.customerButton5);
            this.panel1.Controls.Add(this.customerButton4);
            this.panel1.Controls.Add(this.customerButton3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.customerButton1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(976, 131);
            this.panel1.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.ForeColor = System.Drawing.Color.DarkCyan;
            this.label4.Location = new System.Drawing.Point(706, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 21);
            this.label4.TabIndex = 16;
            this.label4.Text = "Users";
            // 
            // customerButton2
            // 
            this.customerButton2.Image = ((System.Drawing.Image)(resources.GetObject("customerButton2.Image")));
            this.customerButton2.ImageHover = null;
            this.customerButton2.Location = new System.Drawing.Point(710, 12);
            this.customerButton2.Name = "customerButton2";
            this.customerButton2.Size = new System.Drawing.Size(48, 48);
            this.customerButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.customerButton2.TabIndex = 11;
            this.customerButton2.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.ForeColor = System.Drawing.Color.DarkCyan;
            this.label8.Location = new System.Drawing.Point(796, 63);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 21);
            this.label8.TabIndex = 20;
            this.label8.Text = "Orders";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.ForeColor = System.Drawing.Color.DarkCyan;
            this.label7.Location = new System.Drawing.Point(397, 63);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 21);
            this.label7.TabIndex = 19;
            this.label7.Text = "Customers";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.ForeColor = System.Drawing.Color.DarkCyan;
            this.label6.Location = new System.Drawing.Point(500, 63);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(102, 21);
            this.label6.TabIndex = 18;
            this.label6.Text = "Categories";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.ForeColor = System.Drawing.Color.DarkCyan;
            this.label5.Location = new System.Drawing.Point(617, 63);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 21);
            this.label5.TabIndex = 17;
            this.label5.Text = "Staff";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.ForeColor = System.Drawing.Color.DarkCyan;
            this.label2.Location = new System.Drawing.Point(315, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 21);
            this.label2.TabIndex = 0;
            this.label2.Text = "Product";
            // 
            // customerButton6
            // 
            this.customerButton6.Image = ((System.Drawing.Image)(resources.GetObject("customerButton6.Image")));
            this.customerButton6.ImageHover = null;
            this.customerButton6.Location = new System.Drawing.Point(800, 12);
            this.customerButton6.Name = "customerButton6";
            this.customerButton6.Size = new System.Drawing.Size(51, 48);
            this.customerButton6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.customerButton6.TabIndex = 15;
            this.customerButton6.TabStop = false;
            // 
            // customerButton5
            // 
            this.customerButton5.Image = ((System.Drawing.Image)(resources.GetObject("customerButton5.Image")));
            this.customerButton5.ImageHover = null;
            this.customerButton5.Location = new System.Drawing.Point(424, 12);
            this.customerButton5.Name = "customerButton5";
            this.customerButton5.Size = new System.Drawing.Size(44, 48);
            this.customerButton5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.customerButton5.TabIndex = 14;
            this.customerButton5.TabStop = false;
            // 
            // customerButton4
            // 
            this.customerButton4.Image = ((System.Drawing.Image)(resources.GetObject("customerButton4.Image")));
            this.customerButton4.ImageHover = null;
            this.customerButton4.Location = new System.Drawing.Point(518, 12);
            this.customerButton4.Name = "customerButton4";
            this.customerButton4.Size = new System.Drawing.Size(51, 48);
            this.customerButton4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.customerButton4.TabIndex = 13;
            this.customerButton4.TabStop = false;
            // 
            // customerButton3
            // 
            this.customerButton3.Image = ((System.Drawing.Image)(resources.GetObject("customerButton3.Image")));
            this.customerButton3.ImageHover = null;
            this.customerButton3.Location = new System.Drawing.Point(608, 12);
            this.customerButton3.Name = "customerButton3";
            this.customerButton3.Size = new System.Drawing.Size(56, 48);
            this.customerButton3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.customerButton3.TabIndex = 12;
            this.customerButton3.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Goudy Stout", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkCyan;
            this.label1.Location = new System.Drawing.Point(5, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 51);
            this.label1.TabIndex = 10;
            this.label1.Text = "SY";
            // 
            // customerButton1
            // 
            this.customerButton1.Image = ((System.Drawing.Image)(resources.GetObject("customerButton1.Image")));
            this.customerButton1.ImageHover = null;
            this.customerButton1.Location = new System.Drawing.Point(333, 12);
            this.customerButton1.Name = "customerButton1";
            this.customerButton1.Size = new System.Drawing.Size(43, 48);
            this.customerButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.customerButton1.TabIndex = 1;
            this.customerButton1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkCyan;
            this.label3.Location = new System.Drawing.Point(7, 59);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(314, 68);
            this.label3.TabIndex = 9;
            this.label3.Text = "Bicycle Management \r\nSystem";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkCyan;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 598);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(976, 34);
            this.panel2.TabIndex = 1;
            // 
            // panelMain
            // 
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMain.Location = new System.Drawing.Point(0, 131);
            this.panelMain.Margin = new System.Windows.Forms.Padding(4);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(976, 467);
            this.panelMain.TabIndex = 0;
           
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(976, 632);
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customerButton2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerButton6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerButton5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerButton4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerButton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerButton1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Label label3;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label label1;
        private CustomerButton customerButton1;
        private CustomerButton customerButton6;
        private CustomerButton customerButton5;
        private CustomerButton customerButton4;
        private CustomerButton customerButton3;
        private CustomerButton customerButton2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
    }
}